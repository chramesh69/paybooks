package jbr.springmvc.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import jbr.springmvc.model.User;
import jbr.springmvc.service.UserService;

@Controller
public class UpdateController {
  @Autowired
  public UserService userService;

  @RequestMapping(value = "/update", method = RequestMethod.GET)
  public ModelAndView showRegister(HttpServletRequest request, HttpServletResponse response) {
    ModelAndView mav = new ModelAndView("update");
    mav.addObject("user", new User());

    return mav;
  }

  @RequestMapping(value = "/updateProcess", method = RequestMethod.POST)
  public ModelAndView addUser(HttpServletRequest request, HttpServletResponse response,
      @ModelAttribute("user") User user) {
    User user1 = userService.update(user);
    HttpSession session = request.getSession();
    session.setAttribute("user",user);
    return new ModelAndView("update", "user", user1);
  }
  
  @RequestMapping(value = "/changePassword", method = RequestMethod.POST)
  public ModelAndView changePassword(HttpServletRequest request, HttpServletResponse response,
      @ModelAttribute("user") User user) {
    HttpSession session = request.getSession();
   User user1 = (User) session.getAttribute("user");
   user.setUsername(user1.getUsername());
   userService.changePassword(user);

    return new ModelAndView("cp", "user", user1);
  }
  @RequestMapping(value = "/logout", method = RequestMethod.GET)
  public ModelAndView logout(HttpServletRequest request, HttpServletResponse response)
  {
    HttpSession session = request.getSession();
    session.invalidate();
    return new ModelAndView("logout", "logout", "Logged out successfully");
  }
}
